## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning=FALSE, comment='', message=FALSE)

## ---- echo=FALSE---------------------------------------------------------
devtools::load_all(pkg='../../../MRSea')

## ---- eval=FALSE---------------------------------------------------------
## require(MRSea)

## ------------------------------------------------------------------------
data("Nysted.distancecorrected.re")

## ----message=FALSE-------------------------------------------------------
initialModel <- glm(response ~ as.factor(impact) 
                    + offset(log(area)), family = "quasipoisson", 
                    data = mydata)

## ----knotgridnotrun, message=FALSE, fig=TRUE, fig.align='center', fig.width=9, fig.height=6, eval=FALSE----
## knotgrid<- getKnotgrid(coordData = cbind(mydata$x.pos, mydata$y.pos), numKnots = 300, plot = FALSE)

## ----knotgridload, message=FALSE, fig=TRUE, fig.align='center', fig.width=9, fig.height=6, eval=TRUE, echo=FALSE----
data("knotgrid.off")

## ---- warning=FALSE, message=FALSE---------------------------------------
data("nysted.coast")
# make distance matrices for datatoknots and knottoknots
distMatsGeo <- makeDists(datacoords = cbind(mydata$x.pos, mydata$y.pos), knotcoords = knotgrid, polys = nysted.coast)
str(distMatsGeo)

## ---- warning=FALSE, message=FALSE, eval=FALSE---------------------------
## # make distance matrices for datatoknots and knottoknots
## distMatsGeo <- makeDists(datacoords = cbind(mydata$x.pos, mydata$y.pos), knotcoords = knotgrid, polys = list(nysted.coast1, nysted.coast2))

## ---- warning=FALSE, message=FALSE---------------------------------------
distMatsEuc <- makeDists(datacoords = cbind(mydata$x.pos, mydata$y.pos), knotcoords = knotgrid)

## ---- fig.height=3, fig.width=8------------------------------------------
require(fields)
par(mfrow=c(1,2))
#i=299
i=4
zlim=max(range(distMatsEuc$dataDist[,i]), range(distMatsGeo$dataDist[,i]))
quilt.plot(mydata$x.pos, mydata$y.pos, distMatsEuc$dataDist[,i], main='Euclidean', asp=1, zlim=c(0,zlim))
points(knotgrid[i], knotgrid[i,2], pch=20, col='darkgrey', cex=3)
quilt.plot(mydata$x.pos, mydata$y.pos, distMatsGeo$dataDist[,i], main='Geodesic', asp=1, zlim=c(0,zlim))
points(knotgrid[i], knotgrid[i,2], pch=20, col='darkgrey', cex=3)


## ---- fig.height=3, fig.width=5------------------------------------------
quilt.plot(mydata$x.pos, mydata$y.pos, distMatsGeo$dataDist[,i]-distMatsEuc$dataDist[,i], main='Geodesic-Euclidean', asp=1)
points(knotgrid[i], knotgrid[i,2], pch=20, col='darkgrey', cex=3)

## ------------------------------------------------------------------------
# make parameter set for running salsa2d
salsa2dlist<-list(fitnessMeasure = 'QBIC', knotgrid = knotgrid, 
                 startKnots=5, minKnots=4, maxKnots=12, gap=0, 
                 interactionTerm="as.factor(impact)")

## ----echo=FALSE, message=FALSE, warning=FALSE, results='hide'------------
require(MuMIn)
salsa2dOutput<-runSALSA2D(initialModel, salsa2dlist, 
                      d2k=distMatsGeo$dataDist,k2k=distMatsGeo$knotDist)

## ----echo=TRUE, eval=FALSE-----------------------------------------------
## salsa2dOutput<-runSALSA2D(salsa1dOutput$bestModel, salsa2dlist,
##                              d2k=distMatsGeo$dataDist, k2k=distMatsGeo$knotDist)

## ---- fig.height=3, fig.width=5------------------------------------------
plot(mydata$x.pos, mydata$y.pos, col="grey", pch=16,
    xlab="X", ylab="Y", asp=1)
points(knotgrid, pch=16, col=4)
points(knotgrid[salsa2dOutput$aR[[1]],], 
       col="darkgreen", pch=16, cex=2)  

## ------------------------------------------------------------------------
anova(salsa2dOutput$bestModel)

## ----fig=TRUE, fig.align='center', fig.width=8, fig.height=6-------------
par(mfrow=c(2,2))
quilt.plot(mydata$x.pos[mydata$impact==0], 
           mydata$y.pos[mydata$impact==0], 
           (mydata$response)[mydata$impact==0], , nrow=43, ncol=54, asp=1, main='Counts, Before')
quilt.plot(mydata$x.pos[mydata$impact==1], 
           mydata$y.pos[mydata$impact==1], 
           (mydata$response)[mydata$impact==1], nrow=43, ncol=54, asp=1, main='Counts, After')

quilt.plot(mydata$x.pos[mydata$impact==0], 
           mydata$y.pos[mydata$impact==0], 
           fitted(salsa2dOutput$bestModel)[mydata$impact==0], , nrow=43, ncol=54, asp=1, main='Fitted, Before')
quilt.plot(mydata$x.pos[mydata$impact==1], 
           mydata$y.pos[mydata$impact==1], 
           fitted(salsa2dOutput$bestModel)[mydata$impact==1], nrow=43, ncol=54, asp=1, main='Fitted, After')


## ------------------------------------------------------------------------
data("nysted.predictdata") 

## ---- fig.height=3, fig.width=4------------------------------------------
# grid for before and after impact, season not in model
predictdata<-nysted.predictdata[nysted.predictdata$season==1,]
require(splancs)

plot(predictdata$x.pos, predictdata$y.pos, pch=20, col='darkgrey', cex=0.5,ylim=c(6050, 6065))
polymap(nysted.coast, add=T)

## ---- fig.height=3, fig.width=4------------------------------------------
predictdata<-predictdata[which(inout(cbind(predictdata$x.pos, predictdata$y.pos), poly = nysted.coast)==FALSE),]

plot(predictdata$x.pos, predictdata$y.pos, pch=20, col='darkgrey', cex=0.5,ylim=c(6050, 6065))
polymap(nysted.coast, add=T)

## ---- fig.height=3, fig.width=5------------------------------------------
dists<-makeDists(datacoords = cbind(predictdata$x.pos, predictdata$y.pos), 
                 knotcoords = knotgrid, knotmat=FALSE, polys = nysted.coast, type='B')$dataDist
quilt.plot(predictdata$x.pos, predictdata$y.pos, dists[,salsa2dOutput$aR[[1]][1]], main='Prediction Grid', asp=1)

## ------------------------------------------------------------------------
# make predictions on response scale
preds<-predict.gamMRSea(newdata = predictdata, g2k = dists, object = salsa2dOutput$bestModel)

## ----fig=TRUE, fig.align='center', fig.width=8, fig.height=5-------------
par(mfrow=c(1,2))
quilt.plot(predictdata$x.pos[predictdata$impact==0], 
           predictdata$y.pos[predictdata$impact==0], 
           preds[predictdata$impact==0], nrow=80, ncol=40, asp=1)

quilt.plot(predictdata$x.pos[predictdata$impact==1], 
           predictdata$y.pos[predictdata$impact==1], 
           preds[predictdata$impact==1], nrow=80, ncol=40, asp=1)

## ----boots, warning=FALSE, message=FALSE, results='hide'-----------------
bootPreds<-do.bootstrap.cress.robust(model.obj = salsa2dOutput$bestModel, predictionGrid = predictdata, splineParams=salsa2dOutput$bestModel$splineParams, g2k=dists, B = 100, robust=TRUE)

## ------------------------------------------------------------------------
#load('predictionboot.RData')
cis <- makeBootCIs(bootPreds)

## ------------------------------------------------------------------------
differences <- getDifferences(beforePreds = 
                      bootPreds[predictdata$impact == 0, ],
                      afterPreds = bootPreds[predictdata$impact == 1, ])

## ----fig=TRUE, fig.align='center', fig.width=8, fig.height=5-------------
mediandiff <- differences$mediandiff
# The marker for each after - before difference:
# positive ('1') and negative ('-') significant differences
marker <- differences$significanceMarker
par(mfrow = c(1, 1))
quilt.plot(predictdata$x.pos[predictdata$impact == 0], 
           predictdata$y.pos[predictdata$impact == 0],
           mediandiff, asp = 1, nrow = 104, ncol = 54)
# add + or - depending on significance of cells. Just
# requires one significance out of all to be allocated
points(predictdata$x.pos[predictdata$impact == 0][marker == 1],
       predictdata$y.pos[predictdata$impact == 0][marker == 1],
       pch = "+", col = "darkgrey", cex = 0.75)
points(predictdata$x.pos[predictdata$impact == 0][marker == (-1)],
       predictdata$y.pos[predictdata$impact == 0][marker == (-1)],
       col = "darkgrey", cex = 0.75)
points(681417.3/1000, 6046910/1000, cex = 3, pch = "*", lwd = 1, col = "grey")

## ----echo=FALSE, message=FALSE, warning=FALSE, results='hide'------------
salsa2dOutputeuc<-runSALSA2D(initialModel, salsa2dlist, 
                      d2k=distMatsEuc$dataDist,k2k=distMatsEuc$knotDist)

## ---- fig.width=8, fig.height=5------------------------------------------
par(mfrow=c(1,2))
plot(mydata$x.pos, mydata$y.pos, col="grey", pch=16,
    xlab="X", ylab="Y", asp=1, main='Euclidean')
points(knotgrid, pch=16, col=4)
points(knotgrid[salsa2dOutputeuc$aR[[1]],], 
       col="darkgreen", pch=16, cex=2)  
plot(mydata$x.pos, mydata$y.pos, col="grey", pch=16,
    xlab="X", ylab="Y", asp=1, main='Geodesic')
points(knotgrid, pch=16, col=4)
points(knotgrid[salsa2dOutput$aR[[1]],], 
       col="darkgreen", pch=16, cex=2) 

## ------------------------------------------------------------------------
anova(salsa2dOutputeuc$bestModel)
anova(salsa2dOutput$bestModel)

## ------------------------------------------------------------------------
cv.gamMRSea(data=mydata, salsa2dOutput$bestModel, K=10)$delta[2]
cv.gamMRSea(data=mydata, salsa2dOutputeuc$bestModel, K=10)$delta[2]

